package com.example.ump;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView strikesText;
    private TextView ballsText;
    private Button addBall;
    private Button reset;
    private Button addStrike;
    private Button exit;
    private int bcounter;
    private int scounter;

    private View.OnClickListener clickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.addBall :
                    plusbCounter();
                    break;

                case R.id.addStrike :
                    plussCounter();
                    break;

                case R.id.reset :
                    initbCounter();
                    initsCounter();
                    break;

                case R.id.exit :
                    System.exit(0);
            }
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        strikesText = (TextView) findViewById(R.id.strikesText);
        ballsText = (TextView) findViewById(R.id.ballsText);
        addStrike = (Button) findViewById(R.id.addStrike);
        addStrike.setOnClickListener(clickListener);
        addBall = (Button) findViewById(R.id.addBall);
        addBall.setOnClickListener(clickListener);
        reset = (Button) findViewById(R.id.reset);
        reset.setOnClickListener(clickListener);
        exit = (Button) findViewById(R.id.exit);
        exit.setOnClickListener(clickListener);

        initbCounter();
        initsCounter();
    }

    private void initbCounter() {
        bcounter = 0;
        ballsText.setText(bcounter + "");
    }

    private void plusbCounter() {
        bcounter++;
        ballsText.setText(bcounter + "");
    }

    private void initsCounter() {
        scounter = 0;
        strikesText.setText(scounter + "");
    }

    private void plussCounter() {
        scounter++;
        strikesText.setText(scounter + "");
    }
}
