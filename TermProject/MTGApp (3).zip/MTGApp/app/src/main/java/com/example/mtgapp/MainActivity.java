package com.example.mtgapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Vector;

public class MainActivity extends AppCompatActivity {

    private Button addCard;
    private Button viewCards;
    public Vector<String> cardVector = new Vector<>();    //Vector of cards

    private View.OnClickListener clickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.addCard :
                    addNewCard();       //When button is clicked, call function
                    break;
                case R.id.viewCards :
                    setContentView(R.layout.activity_view_collection);       //When button is clicked, switch view
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        addCard = (Button) findViewById(R.id.addCard);      //Set up button
        addCard.setOnClickListener(clickListener);

        viewCards = (Button) findViewById(R.id.viewCards);      //Set up button
        viewCards.setOnClickListener(clickListener);
    }

    public void addNewCard() {      //Add card information from the app activity into the class vector
        TextView addName = (TextView) findViewById(R.id.addName);
        String name = addName.getText().toString();
        TextView addType = (TextView) findViewById(R.id.addType);
        String type = addType.getText().toString();
        TextView addMana = (TextView) findViewById(R.id.addMana);
        String mana = addMana.getText().toString();
        TextView addSet = (TextView)findViewById(R.id.addSet);
        String set = addSet.getText().toString();
        TextView addCost = (TextView)findViewById(R.id.addCost);
        String scost = addCost.getText().toString();
        int cost = Integer.parseInt(scost);
        TextView addRarity = (TextView)findViewById(R.id.addRarity);
        String rarity = addRarity.getText().toString();

        Cards card1 = new Cards(name, type, cost, mana, rarity, set);
        cardVector.add(card1.toString());
    }
}
