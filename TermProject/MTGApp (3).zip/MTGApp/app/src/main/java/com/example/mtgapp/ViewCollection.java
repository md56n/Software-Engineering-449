package com.example.mtgapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ViewCollection extends AppCompatActivity {

    private Button back;    //Back button

    private View.OnClickListener clickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.back :
                    setContentView(R.layout.activity_main);       //When button is clicked, switch view
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_collection);

        back = (Button) findViewById(R.id.back);      //Set up button
        back.setOnClickListener(clickListener);
    }
}
