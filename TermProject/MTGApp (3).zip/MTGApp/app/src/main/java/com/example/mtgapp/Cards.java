package com.example.mtgapp;

//Class declaration

public class Cards {
    //Variables
    String name;
    String type;
    int cost;
    String color;
    String rarity;
    String set;

    //Constructor declaration
    public Cards(String name, String type, int cost, String color, String rarity, String set) {
        this.name = name;
        this.type = type;
        this.cost = cost;
        this.color = color;
        this.rarity = rarity;
        this.set = set;
    }

    //Name
    public String getName() {
        return name;
    }

    //Type
    public String getType() {
        return type;
    }

    //Cost
    public int getCost() {
        return cost;
    }

    //Color
    public String getColor() {
        return color;
    }

    //Rarity
    public String getRarity() {
        return rarity;
    }

    //Set
    public String getSet() {return set; }

    //Info string
    public String toString() {
        String total = this.getName() + " is a " + this.getColor() + this.getType() + " that costs " + this.getCost() + ". It is a " + this.getRarity() + "from the " + this.getSet() + " set.";
        return total;
    }
}
