package com.example.ump;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {

    private TextView strikesText;
    private TextView ballsText;
    private Button addBall;
    private Button reset;
    private Button addStrike;
    private Button exit;
    private Button about;
    private int bcounter;
    private int scounter;

    private View.OnClickListener clickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.about :
                    viewAbout();
                    break;

                case R.id.addBall :
                    plusbCounter();
                    break;

                case R.id.addStrike :
                    plussCounter();
                    break;

                case R.id.reset :
                    initbCounter();
                    initsCounter();
                    addStrike.setEnabled(true);
                    addBall.setEnabled(true);
                    break;

                case R.id.exit :
                    System.exit(0);
            }
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        strikesText = (TextView) findViewById(R.id.strikesText);
        ballsText = (TextView) findViewById(R.id.ballsText);
        addStrike = (Button) findViewById(R.id.addStrike);
        addStrike.setOnClickListener(clickListener);
        addBall = (Button) findViewById(R.id.addBall);
        addBall.setOnClickListener(clickListener);
        reset = (Button) findViewById(R.id.reset);
        reset.setOnClickListener(clickListener);
        exit = (Button) findViewById(R.id.exit);
        exit.setOnClickListener(clickListener);
        about = (Button) findViewById(R.id.about);
        about.setOnClickListener(clickListener);

        initbCounter();
        initsCounter();
        addStrike.setEnabled(true);
        addBall.setEnabled(true);
    }

    private void initbCounter() {
        bcounter = 0;
        ballsText.setText(bcounter + "");
    }

    private void plusbCounter() {
        bcounter++;
        ballsText.setText(bcounter + "");
        if(bcounter==4) {
            ballsTotal();
        }
    }

    private void initsCounter() {
        scounter = 0;
        strikesText.setText(scounter + "");
    }

    private void plussCounter() {
        scounter++;
        strikesText.setText(scounter + "");
        if(scounter==3) {
            strikesTotal();
        }
    }

    private void ballsTotal() {
        addStrike.setEnabled(false);
        addBall.setEnabled(false);
        AlertDialog.Builder alertB = new AlertDialog.Builder(this);
        alertB.setTitle("4 Balls");
        alertB.setMessage("Walk!");
        alertB.setNeutralButton("Close", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        alertB.create().show();
    }

    private void strikesTotal() {
        addStrike.setEnabled(false);
        addBall.setEnabled(false);
        AlertDialog.Builder alertS = new AlertDialog.Builder(this);
        alertS.setTitle("3 Strikes");
        alertS.setMessage("Out!");
        alertS.setNeutralButton("Close", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        alertS.create().show();
    }

    public void viewAbout() {
        Intent intent = new Intent(MainActivity.this, AboutActivity.class);
        startActivity(intent);
    }
}
